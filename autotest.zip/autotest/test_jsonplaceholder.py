import pytest
import requests

BASE_URL = "https://jsonplaceholder.typicode.com"

def test_create_post():
    """Тест успешного создания поста"""
    new_post = {
        "title": "Test Post Title",
        "body": "Test post content",
        "userId": 1
    }
    
    response = requests.post(f"{BASE_URL}/posts", json=new_post)
    
    assert response.status_code == 201, f"Ожидался статус 201, получен {response.status_code}"
    
    response_data = response.json()
    assert "id" in response_data
    assert response_data["title"] == new_post["title"]
    assert response_data["body"] == new_post["body"]
    assert response_data["userId"] == new_post["userId"]
    print(f"✅ Пост успешно создан с ID: {response_data['id']}")

def test_update_post():
    """Тест успешного изменения поста"""
    post_id = 1
    updated_data = {
        "title": "Updated Title",
        "body": "Updated content",
        "userId": 1
    }
    
    response = requests.put(f"{BASE_URL}/posts/{post_id}", json=updated_data)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    
    response_data = response.json()
    assert response_data["id"] == post_id
    assert response_data["title"] == updated_data["title"]
    assert response_data["body"] == updated_data["body"]
    print(f"✅ Пост {post_id} успешно изменен")

def test_delete_post():
    """Тест успешного удаления поста"""
    post_id = 1
    
    response = requests.delete(f"{BASE_URL}/posts/{post_id}")
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    
    # API возвращает пустой объект после удаления
    assert response.json() == {}, "Ответ должен быть пустым объектом"
    print(f"✅ Пост {post_id} успешно удален")

if __name__ == "__main__":
    pytest.main([__file__, "-v"])